<?php
    $servername = "localhost";
    $username = "root";
    $password = "usbw";
    $dbname = "usuarios";

    $conn = mysqli_connect($servername, $username, $password, $dbname);
    if (!$conn) die("Connection failed: " . mysqli_connect_error());

    $nome = $_POST['nome'];
    $senha = $_POST['senha'];

    $sql = "INSERT INTO cadastro (usuario, senha)
    VALUES ('$nome', '$senha')";

    if (mysqli_query($conn, $sql)) {
        echo "Novo veículo cadastrado com sucesso!";
    } else {
        echo "Ocorreu um erro: " . $sql . "<br>" . mysqli_error($conn);
    }

    mysqli_close($conn);
?>
