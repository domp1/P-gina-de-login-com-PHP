<?php 
    $servername = "localhost";
    $username = "root";
    $password = "usbw";
    $dbname = "usuarios";

    $conn = mysqli_connect($servername, $username, $password, $dbname);
    if (!$conn) die("Connection failed: " . mysqli_connect_error());

    $nome = $_POST['nome'];
    $senha = $_POST['senha'];

    $sql = "SELECT * FROM cadastro";
    $result = mysqli_query($conn, $sql);

    if (mysqli_num_rows($result) > 0) {
        while($row = mysqli_fetch_assoc($result)){
            if($row['usuario']==$nome && $row['senha']==$senha) {
                echo "<pre>";
                print_r("Bem vindo! ");
            }else echo "Usuário não existe!";
        }
    }else echo "0 resultados";

    mysqli_close($conn);
?>
